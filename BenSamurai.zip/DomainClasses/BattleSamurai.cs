﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainClasses
{
    public class BattleSamurai
    {
        public int BattleSamuraiId { get; set; }
        public int SamuraiId { get; set; }
        public int BattleId { get; set; }
    }
}
